# Flutter Service App

A basic service app with Customer and Employee roles.
